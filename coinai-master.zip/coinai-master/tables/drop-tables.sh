aws dynamodb delete-table --table-name FactorModel
aws dynamodb delete-table --table-name Company
aws dynamodb delete-table --table-name RegimeModel
aws dynamodb delete-table --table-name Portfolio
aws dynamodb delete-table --table-name Users
aws dynamodb delete-table --table-name Coin
aws dynamodb delete-table --table-name ReferenceData
aws dynamodb delete-table --table-name RiskFactor

aws dynamodb delete-table --table-name PerformanceData
aws dynamodb delete-table --table-name Session



