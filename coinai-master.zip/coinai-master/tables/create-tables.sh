aws dynamodb create-table --cli-input-json file://./FactorModel.json
aws dynamodb create-table --cli-input-json file://./Company.json
aws dynamodb create-table --cli-input-json file://./RegimeModel.json
aws dynamodb create-table --cli-input-json file://./Portfolio.json
aws dynamodb create-table --cli-input-json file://./Users.json


aws dynamodb create-table --cli-input-json file://./Coin.json
aws dynamodb create-table --cli-input-json file://./ReferenceData.json
aws dynamodb create-table --cli-input-json file://./RiskFactor.json
aws dynamodb create-table --cli-input-json file://./PerformanceData.json
aws dynamodb create-table --cli-input-json file://./Session.json



