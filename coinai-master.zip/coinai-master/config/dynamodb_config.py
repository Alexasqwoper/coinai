dynamoDB = {
    "region_name":"NA",
    "aws_access_key_id":"",
    
    "aws_secret_access_key":""
}
