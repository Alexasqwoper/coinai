
scheduler_hour_time = {
    "month":"*",
    "day":"*",
    "hour":"*",
    "minute":"15,45",
    "second":"1"
}

scheduler_day_time = {
    "month":"*",
    "day":"*",
    "hour":"0",
    "minute":"5",
    "second":"1"
}

scheduler_minute_time = {
    "month":"*",
    "day":"*",
    "hour":"*",
    "minute":"0,10,20,30,40,50",
    "second":"1"
}

timezone_local = ""
